<div id="footer" class="clear" style="text-align:center; padding:10px">
  <!-- Paste advert code under this line -->
  <p>
    Made by Exote. WebAuction v0.6.4<br/>
    For more usage info visit the <a href="http://dev.bukkit.org/server-mods/webauction">BukkitDev site</a>.
  </p>
</div>
