WebAuctionPlus - Visit our BukkitDev page for more info.
http://dev.bukkit.org/server-mods/webauctionplus/
